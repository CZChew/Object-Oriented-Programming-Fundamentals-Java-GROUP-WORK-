// Package not detected, please report project structure on CodeTogether's GitHub Issues
package foo.bar;

public class textRanking {

}
