import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class TestRanking {  
	
	public void RankingTest() throws FileNotFoundException {
		
		Scanner list = new Scanner(new File("TopScore.txt"));

        ArrayList<Double> scoreList = new ArrayList<Double>();

        while(list.hasNextLine()){
            String line = list.nextLine();

            Scanner scanner = new Scanner(line);
            scanner.useDelimiter(",");
            while(scanner.hasNextDouble()){
                scoreList.add(scanner.nextDouble());
            }
            scanner.close();
        }

        list.close();

        System.out.println(scoreList);
        System.out.print(scoreList.get(0));
	}

  public static void main (String[] args) throws FileNotFoundException{
			TestRanking lis = new TestRanking();
			lis.RankingTest();

  } 
}
