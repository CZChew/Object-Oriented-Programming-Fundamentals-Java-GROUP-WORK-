import java.util.Scanner;

public class test {
	public static void main(String[] args) {
	    Scanner scan = new Scanner (System.in);
	    System.out.println ("Enter a noun that classifies the"
	                        + " type of your product:");

	    String noun = scan.nextLine();
	    String inputnoun = noun.split(" ")[0];
	    
	    System.out.println(inputnoun);
	}
}
