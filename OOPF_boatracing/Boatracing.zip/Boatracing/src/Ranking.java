import java.io.File;
import java.io.FileNotFoundException;
import java.lang.SecurityException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Ranking {  

    public void getTopScore() {      //Display Top 5
        Scanner input;
        try {
			input = new Scanner(new File("TopScore.txt"));
			while (input.hasNext()) {
				System.out.printf("%-15s%-10d\n", input.next(), input.nextInt());
			}
			if (input != null) {
                input.close();
            }
		}
		catch (SecurityException se) {
                System.out.println("You do not have write access");
                System.exit(1);
        } 
        catch (FileNotFoundException fe) {
               System.out.println("Error opening/creating file.");
               System.exit(1);
        }
    }
//File input 
    static class Player {
    String name;
    int marks;
    int prev_rank;

    Player(){
        this.marks = 0;
        this.prev_rank = 0;
    }

    static void nameRank(String []names, int []marks){

    }
    
    }
}
